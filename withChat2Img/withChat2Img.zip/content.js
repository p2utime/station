(() => {
  if (window.__yutExcerptLoaded) return;
  window.__yutExcerptLoaded = true;

  const isAppPage = () => location.hostname === 'purewith.me' && location.pathname.startsWith('/Chat2Img') && !!document.getElementById('in-text');

  let settings = { showBubble: true, speakerChips: 2, sites: YUT_DEFAULT_SITES, allSites: false };
  let lastMode = 'normal';
  chrome.storage.sync.get(settings).then((s) => (settings = s));
  chrome.storage.local.get({ lastMode: 'normal' }).then((s) => (lastMode = s.lastMode));
  chrome.storage.onChanged.addListener((ch) => {
    for (const k of ['showBubble', 'speakerChips', 'sites', 'allSites']) if (ch[k]) settings[k] = ch[k].newValue;
    if (ch.lastMode) lastMode = ch.lastMode.newValue;
    if (!siteOn()) hideBar();
  });
  // 이 사이트가 켜져 있는지 (설정에서 끄면 새로고침 없이 바로 멈춤)
  const siteOn = () => settings.allSites || !!yutMatchHost(location.hostname, settings.sites);

  // 발췌기 페이지 자체에서는 버튼을 띄우지 않음
  if (isAppPage()) {
    const report = () => {
      const m = document.querySelector('.mode-tab-btn.on')?.dataset.mode;
      if (m) chrome.runtime.sendMessage({ type: 'yut-mode', mode: m }).catch(() => {});
    };
    report();
    document.addEventListener('click', (e) => {
      if (e.target.closest?.('.mode-tab-btn')) setTimeout(report, 50);
    });
  }

  // ---------- 떠 있는 버튼 ----------
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:0;top:0;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      .bar {
        display: none; align-items: center; gap: 4px; padding: 4px;
        background: #fff; border: 1px solid rgba(0,0,0,.08); border-radius: 999px;
        box-shadow: 0 6px 22px rgba(20,40,60,.18), 0 1px 3px rgba(0,0,0,.08);
        font: 700 12.5px/1 Pretendard, -apple-system, "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif;
        user-select: none; -webkit-user-select: none; letter-spacing: -0.02em;
        animation: pop .14s ease-out;
      }
      .bar.show { display: inline-flex; }
      @keyframes pop { from { transform: translateY(4px) scale(.96); opacity: 0; } to { transform: none; opacity: 1; } }
      button {
        all: unset; cursor: pointer; box-sizing: border-box; height: 28px; padding: 1px 11px 0; /* 글자가 위로 떠 보여서 1px 내림 */
        border-radius: 999px; color: #3A3F47; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px;
      }
      button:hover { background: rgba(47,164,222,.1); color: #1C86C2; }
      .main { background: #2FA4DE; color: #fff; }
      .main:hover { background: #1C86C2; color: #fff; }
      .sep { width: 1px; height: 16px; background: #e2e8f0; margin: 0 2px; }
      .chip { width: 28px; padding: 1px 0 0; justify-content: center; border: 1px solid #dbe7f0; font-size: 12px; }
      .lbl { color: #94a3b8; font-size: 11px; padding: 1px 2px 0 4px; }
      .toast {
        display: none; padding: 9px 13px; border-radius: 12px; background: #0E0F12; color: #fff;
        font: 600 12.5px/1.4 Pretendard, -apple-system, "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif;
        box-shadow: 0 6px 22px rgba(0,0,0,.22); max-width: 320px;
      }
      .toast.err { background: #e5484d; }
      .toast.show { display: block; animation: pop .14s ease-out; }
    </style>
    <div class="bar" part="bar">
      <button class="main" data-act="new" title="이 글을 발췌기에 넣습니다">✦ 발췌</button>
      <button data-act="add" title="발췌기에 쓰던 글은 두고, 그 아래에 붙여넣습니다">이어 붙이기</button>
      <span class="speakers"></span>
    </div>
    <div class="toast"></div>
  `;
  const bar = root.querySelector('.bar');
  const toastEl = root.querySelector('.toast');
  const speakersEl = root.querySelector('.speakers');
  let pendingText = '';
  let toastTimer = null;

  const mount = () => { if (!host.isConnected) document.documentElement.appendChild(host); };

  function renderSpeakers() {
    const n = Math.max(0, Math.min(6, Number(settings.speakerChips) || 0));
    if (lastMode !== 'chat' || !n) { speakersEl.innerHTML = ''; return; }
    let html = '<span class="sep" style="display:inline-block;vertical-align:middle"></span><span class="lbl">채팅</span>';
    for (let i = 1; i <= n; i++) html += `<button class="chip" data-act="speaker" data-n="${i}" title="채팅 ${i}번 말풍선으로, 쓰던 대화 아래에 이어 붙여요">${i}</button>`;
    speakersEl.innerHTML = html;
    speakersEl.style.display = 'inline-flex';
    speakersEl.style.alignItems = 'center';
    speakersEl.style.gap = '4px';
  }

  function place(x, y) {
    mount();
    const w = host.offsetWidth || 220, h = host.offsetHeight || 36;
    const vw = document.documentElement.clientWidth || innerWidth;
    const vh = document.documentElement.clientHeight || innerHeight;
    let left = Math.min(Math.max(8, x - w / 2), vw - w - 8);
    let top = y + 8;
    if (top + h > vh - 8) top = Math.max(8, y - h - 34);
    host.style.left = left + 'px';
    host.style.top = top + 'px';
  }

  function showBar(text, x, y) {
    pendingText = text;
    hideToast();
    renderSpeakers();
    mount();
    bar.classList.add('show');
    place(x, y);
  }

  function hideBar() { bar.classList.remove('show'); }
  function hideToast() { toastEl.classList.remove('show'); clearTimeout(toastTimer); }

  function showToast(text, ok, anchor) {
    hideBar();
    mount();
    toastEl.textContent = text;
    toastEl.classList.toggle('err', !ok);
    toastEl.classList.add('show');
    if (anchor) place(anchor.x, anchor.y);
    else {
      const vw = document.documentElement.clientWidth || innerWidth;
      const vh = document.documentElement.clientHeight || innerHeight;
      host.style.left = Math.max(8, vw - toastEl.offsetWidth - 18) + 'px';
      host.style.top = Math.max(8, vh - toastEl.offsetHeight - 18) + 'px';
    }
    clearTimeout(toastTimer);
    toastTimer = setTimeout(hideToast, ok ? 1800 : 4000);
  }

  function selectionInfo() {
    const sel = getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const text = String(sel);
    if (!text.trim()) return null;
    const range = sel.getRangeAt(sel.rangeCount - 1);
    const rects = Array.from(range.getClientRects()).filter((r) => r.width || r.height);
    const r = rects[rects.length - 1] || range.getBoundingClientRect();
    return { text, x: r.right, y: r.bottom };
  }

  let mouse = { x: 0, y: 0 };
  function check(fromMouse) {
    if (!settings.showBubble || isAppPage() || !siteOn()) return;
    const info = selectionInfo();
    if (!info) { hideBar(); return; }
    // 선택 영역 끝 좌표가 이상하면 마우스 위치 기준
    const useMouse = fromMouse && (!info.x && !info.y);
    showBar(info.text, useMouse ? mouse.x : info.x, useMouse ? mouse.y : info.y);
  }

  const inHost = (e) => e.composedPath().includes(host);

  document.addEventListener('mouseup', (e) => {
    if (inHost(e) || e.button !== 0) return;
    mouse = { x: e.clientX, y: e.clientY };
    setTimeout(() => check(true), 10);
  }, true);

  document.addEventListener('keyup', (e) => {
    if (e.key === 'Escape') { hideBar(); hideToast(); return; }
    if (e.shiftKey || e.key === 'Shift' || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a')) setTimeout(() => check(false), 10);
  }, true);

  document.addEventListener('mousedown', (e) => {
    if (inHost(e)) { e.preventDefault(); return; } // 버튼 눌러도 선택이 풀리지 않게
    hideBar();
  }, true);

  addEventListener('scroll', () => hideBar(), { capture: true, passive: true });
  addEventListener('resize', () => hideBar());

  root.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const act = btn.dataset.act;
    const text = pendingText;
    const rect = host.getBoundingClientRect();
    const anchor = { x: rect.left + rect.width / 2, y: rect.top - 8 };
    hideBar();
    let res;
    try {
      res = await chrome.runtime.sendMessage({
        type: 'yut-excerpt',
        text,
        replace: act === 'new',
        speaker: act === 'speaker' ? Number(btn.dataset.n) : null,
      });
    } catch (err) {
      res = { ok: false, error: '확장프로그램이 업데이트됐습니다. 페이지를 새로고침해 주세요.' };
    }
    if (!res) res = { ok: false, error: '응답이 없습니다. 잠시 뒤 다시 시도해 주세요.' };
    showToast(res.ok ? res.message : res.error, res.ok, anchor);
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'yut-toast' && window === window.top) showToast(msg.text, msg.ok);
  });
})();