const APP_URL = 'https://purewith.me/Chat2Img/'; // 트위터프사
const SNS_IMAGE = 'icons/pro.png';
const DEFAULTS = { showBubble: true, focusOnSend: false, cleanText: true, speakerChips: 2 };
const $ = (id) => document.getElementById(id);

function flash(id = 'saved') {
  const el = $(id);
  el.classList.add('on');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('on'), 1200);
}

function setSeg(v) {
  for (const b of $('speakerChips').querySelectorAll('button')) b.classList.toggle('on', Number(b.dataset.v) === Number(v));
}

async function load() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $('showBubble').checked = s.showBubble;
  $('focusOnSend').checked = s.focusOnSend;
  $('cleanText').checked = s.cleanText;
  setSeg(s.speakerChips);
}

$('open').addEventListener('click', () => chrome.tabs.create({ url: APP_URL }));

for (const id of ['showBubble', 'focusOnSend', 'cleanText']) {
  $(id).addEventListener('change', async () => {
    await chrome.storage.sync.set({ [id]: $(id).checked });
    flash();
  });
}

$('speakerChips').addEventListener('click', async (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  setSeg(b.dataset.v);
  await chrome.storage.sync.set({ speakerChips: Number(b.dataset.v) });
  flash();
});

$('shortcuts').addEventListener('click', (e) => {
  e.preventDefault();
  const isWhale = /Whale\//.test(navigator.userAgent);
  chrome.tabs.create({ url: isWhale ? 'whale://extensions/shortcuts' : 'chrome://extensions/shortcuts' });
});

const img = new Image();
img.alt = '';
img.onload = () => { const icon = $('sns-icon'); icon.innerHTML = ''; icon.classList.add('has-img'); icon.appendChild(img); };
img.src = SNS_IMAGE;

// ═══════════════ 버튼을 띄울 사이트 ═══════════════
const SITE_DEFAULTS = { sites: YUT_DEFAULT_SITES, allSites: false };
const escHtml = (t) => String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function hint(text, kind) {
  const el = $('siteHint');
  el.textContent = text || '';
  el.className = 'site-hint' + (kind ? ' ' + kind : '');
}

async function renderSites() {
  const { sites, allSites } = await chrome.storage.sync.get(SITE_DEFAULTS);
  $('allSites').checked = allSites;
  $('siteBox').classList.toggle('all', allSites);
  const rows = await Promise.all(sites.map(async (h) => {
    let granted = true;
    try { granted = await chrome.permissions.contains({ origins: yutPatterns(h) }); } catch (e) {}
    return { h, granted };
  }));
  $('siteList').innerHTML = rows.length
    ? rows.map(({ h, granted }) => `
      <li data-host="${escHtml(h)}">
        <span class="site-av">${escHtml(h[0])}</span>
        <span class="site-name"><span>${escHtml(h)}</span>${YUT_DEFAULT_SITES.includes(h) ? '<em class="site-tag">기본</em>' : ''}</span>
        ${granted ? '' : '<button type="button" class="site-need" data-act="grant" title="이 사이트의 권한이 없어 버튼이 뜨지 않습니다">권한 허용</button>'}
        <button type="button" class="site-del" data-act="del" aria-label="${escHtml(h)} 삭제" title="목록에서 빼기">
          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2.5 2.5l7 7M9.5 2.5l-7 7"/></svg>
        </button>
      </li>`).join('')
    : '<li class="site-empty">켜 둔 사이트가 없습니다. 위에서 주소를 추가해 주세요.</li>';
  $('siteCount').textContent = allSites ? '모든 사이트에서 켜져 있습니다' : `${sites.length}개 사이트에서 켜짐`;
}

async function saveSites(sites) {
  await chrome.storage.sync.set({ sites });
  flash('saved-sites');
  renderSites();
}

// 추가 — 권한 요청은 클릭(엔터) 직후 바로 해야 해서 먼저 부름
function addSite() {
  const host = yutHostFromInput($('siteInput').value);
  if (!host) { hint('주소를 다시 확인해 주세요. (예: caveduck.io 또는 https://caveduck.io/ko)', 'err'); return; }
  chrome.permissions.request({ origins: yutPatterns(host) }).then(async (granted) => {
    if (!granted) { hint('권한을 허용해야 이 사이트에서 버튼이 뜹니다.', 'err'); return; }
    const { sites } = await chrome.storage.sync.get(SITE_DEFAULTS);
    if (sites.includes(host)) { hint(`${host} 은(는) 이미 목록에 있습니다.`, 'ok'); return; }
    await saveSites([...sites, host]);
    chrome.runtime.sendMessage({ type: 'yut-site-on', host }).catch(() => {});
    $('siteInput').value = '';
    hint(`${host} 을(를) 추가했습니다. 열려 있는 탭에도 바로 적용됩니다.`, 'ok');
  }).catch(() => hint('권한을 요청하지 못했습니다.', 'err'));
}
$('siteAddBtn').addEventListener('click', addSite);
$('siteInput').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) addSite(); });

$('siteList').addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  const li = e.target.closest('li[data-host]');
  if (!btn || !li) return;
  const host = li.dataset.host;
  if (btn.dataset.act === 'grant') {
    chrome.permissions.request({ origins: yutPatterns(host) }).then((ok) => {
      if (ok) chrome.runtime.sendMessage({ type: 'yut-site-on', host }).catch(() => {});
      renderSites();
    });
    return;
  }
  chrome.storage.sync.get(SITE_DEFAULTS).then(async ({ sites }) => {
    await saveSites(sites.filter((s) => s !== host));
    if (!YUT_DEFAULT_SITES.includes(host)) chrome.permissions.remove({ origins: yutPatterns(host) }).catch(() => {});
    hint(`${host} 을(를) 목록에서 뺐습니다.`);
  });
});

$('siteReset').addEventListener('click', async () => {
  if (!confirm('사이트 목록을 처음 설치했을 때로 되돌릴까요? 직접 추가한 사이트는 목록에서 빠집니다.')) return;
  await saveSites([...YUT_DEFAULT_SITES]);
  hint('기본 목록으로 되돌렸습니다.');
});

$('allSites').addEventListener('change', () => {
  const on = $('allSites').checked;
  if (on) {
    chrome.permissions.request({ origins: [YUT_ALL_PATTERN] }).then(async (granted) => {
      if (!granted) { $('allSites').checked = false; hint('권한을 허용해야 모든 사이트에서 켤 수 있습니다.', 'err'); return; }
      await chrome.storage.sync.set({ allSites: true });
      chrome.runtime.sendMessage({ type: 'yut-site-on', host: '*' }).catch(() => {});
      flash('saved-sites');
      renderSites();
    });
  } else {
    chrome.storage.sync.set({ allSites: false }).then(() => {
      chrome.permissions.remove({ origins: [YUT_ALL_PATTERN] }).catch(() => {});
      flash('saved-sites');
      renderSites();
    });
  }
});

chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'sync' && (ch.sites || ch.allSites)) renderSites();
});

// ═══════════════ 버전 · 새 버전 알림 ═══════════════
const CURRENT_VER = chrome.runtime.getManifest().version;
$('extVer').textContent = 'v' + CURRENT_VER;

function renderUpdate(u) {
  const box = $('updBox'), state = $('updState');
  box.classList.toggle('new', !!u?.hasUpdate);
  if (u?.hasUpdate) {
    $('updVer').innerHTML = `새 버전 <b>v${escHtml(u.latest)}</b> 이 나왔습니다`;
    state.className = 'upd-state';
    state.textContent = `지금 쓰는 버전 v${CURRENT_VER}` + (u.note ? ` · ${u.note}` : '');
  } else {
    $('updVer').innerHTML = `지금 쓰는 버전 <b>v${escHtml(CURRENT_VER)}</b>`;
    state.className = 'upd-state' + (u?.ok ? ' ok' : '');
    state.textContent = u?.ok ? '최신 버전입니다' : '';
  }
}
chrome.storage.local.get({ update: null }).then(({ update }) => renderUpdate(update));
$('updCheck').addEventListener('click', async () => {
  $('updCheck').textContent = '확인 중…';
  const u = await chrome.runtime.sendMessage({ type: 'yut-check-update' }).catch(() => null);
  renderUpdate(u);
  $('updCheck').textContent = '다시 확인';
  if (u && !u.ok) { $('updState').className = 'upd-state'; $('updState').textContent = '확인하지 못했습니다. 인터넷 연결을 확인해 주세요.'; }
});

load();
renderSites();