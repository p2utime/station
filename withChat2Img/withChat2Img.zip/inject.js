// 발췌기 탭 안에서 실행
function yutInjectExcerpt(item) {
  const W = window;
  const ta = document.getElementById('in-text');
  if (!ta) return { ok: false, error: '이 탭에서 발췌기 본문 칸을 찾지 못했습니다.' };

  const SAMPLE_NORMAL = '내용을 입력하세요! ( _ _)♡';
  const STORAGE_KEY = 'uxi_card_maker_state';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const currentMode = () => document.querySelector('.mode-tab-btn.on')?.dataset.mode || 'normal';
  const modalOpen = () => {
    const m = document.getElementById('restore-modal');
    return !!m && getComputedStyle(m).display !== 'none';
  };

  W.__yutQ = W.__yutQ || [];
  W.__yutQ.push(item);
  if (!W.__yutFlushing) {
    W.__yutFlushing = true;
    run();
  }
  let hasSavedNow = false;
  try { hasSavedNow = !!localStorage.getItem(STORAGE_KEY); } catch (e) {}
  const waiting = modalOpen() || (!!item.fresh && hasSavedNow);
  return { ok: true, mode: currentMode(), waiting };

  async function run() {
    let added = 0;
    try {
      await waitReady();
      W.__yutReadyOnce = true;
      while (W.__yutQ.length) {
        insert(W.__yutQ.shift());
        added++;
      }
    } catch (e) {
      console.warn('[윳! 발췌 도우미]', e);
    } finally {
      W.__yutFlushing = false;
      banner(null);
      if (added) toast(`✦ 발췌 ${added}건을 넣었습니다`);
    }
  }

  // 막 열린 발췌기는 "이전 작업 복원" 창이 뜨고, 고르는 순간 본문을 덮어써요.
  // 그래서 복원 여부가 정해질 때까지 기다렸다가 넣어요.
  async function waitReady() {
    if (W.__yutReadyOnce && !modalOpen()) return;
    let hasSaved = false;
    try { hasSaved = !!localStorage.getItem(STORAGE_KEY); } catch (e) {}
    // 복원 창은 폰트를 다 불러온 직후에 떠요. 막 열린 탭일 때만 잠깐 지켜봄.
    if (hasSaved && !modalOpen() && performance.now() < 10000) {
      try { await document.fonts.ready; } catch (e) {}
      const t0 = Date.now();
      while (!modalOpen() && Date.now() - t0 < 1500) await sleep(100);
    }
    if (modalOpen()) {
      banner('✦ 이전 작업을 복원할지 고르면 가져온 글이 이어서 들어갑니다');
      const before = ta.value;
      while (modalOpen()) await sleep(150);
      // 복원은 저장된 이미지를 읽은 다음 본문을 채우므로 값이 바뀔 때까지 조금 기다림
      const t0 = Date.now();
      await sleep(250);
      while (ta.value === before && Date.now() - t0 < 2000) await sleep(100);
      await sleep(100);
    } else if (performance.now() < 3000) {
      await sleep(600); // 첫 화면 그리기가 끝날 시간
    }
  }

  function insert({ text, replace, speaker }) {
    const mode = currentMode();
    if (speaker && mode === 'chat') {
      text = text
        .split('\n')
        .map((l) => {
          const t = l.trim();
          if (!t) return '';
          if (/^\[([1-6]|s|-)\]/i.test(t) || /^--.+--$/.test(t)) return t;
          return `[${speaker}] ${t}`;
        })
        .filter(Boolean)
        .join('\n');
    }

    const cur = ta.value;
    const isSample =
      !cur.trim() ||
      cur === SAMPLE_NORMAL ||
      (cur.startsWith('--YYYY년 MM월 DD일--') && cur.includes('[1] 채팅 모드입니다.'));

    let insertText, next;
    if (replace || isSample) {
      insertText = text;
      next = text;
    } else {
      const want = mode === 'chat' ? '\n' : '\n\n';
      let sep = want;
      if (cur.endsWith('\n\n')) sep = '';
      else if (cur.endsWith('\n')) sep = want.slice(1);
      insertText = sep + text;
      next = cur + insertText;
    }

    // execCommand 로 넣으면 발췌기에서 Ctrl+Z 로 되돌릴 수 있고 안 되면 값 직접 바꾸기
    const prevActive = document.activeElement;
    let done = false;
    try {
      ta.focus({ preventScroll: true });
      if (replace || isSample) ta.select();
      else ta.setSelectionRange(cur.length, cur.length);
      document.execCommand('insertText', false, insertText);
      done = ta.value === next;
    } catch (e) {}
    if (!done) {
      ta.value = next;
      ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    ta.scrollTop = ta.scrollHeight;
    if (prevActive && prevActive !== ta && prevActive !== document.body) {
      try { prevActive.focus({ preventScroll: true }); } catch (e) {}
    }
  }

  function banner(msg) {
    let el = document.getElementById('__yut-banner');
    if (!msg) { el?.remove(); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = '__yut-banner';
      el.style.cssText =
        'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:2147483647;' +
        'background:#51aae1;color:#fff;font:600 13px/1.4 Pretendard,system-ui,sans-serif;' +
        'padding:10px 16px;border-radius:999px;box-shadow:0 6px 20px rgba(0,0,0,.18);pointer-events:none;';
      document.documentElement.appendChild(el);
    }
    el.textContent = msg;
  }

  function toast(msg) {
    const el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText =
      'position:fixed;right:18px;bottom:18px;z-index:2147483647;background:#1a1b1d;color:#fff;' +
      'font:600 13px/1.4 Pretendard,system-ui,sans-serif;padding:10px 14px;border-radius:12px;' +
      'box-shadow:0 6px 20px rgba(0,0,0,.2);opacity:0;transition:opacity .2s;pointer-events:none;';
    document.documentElement.appendChild(el);
    requestAnimationFrame(() => (el.style.opacity = '1'));
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 250); }, 1800);
  }
}
