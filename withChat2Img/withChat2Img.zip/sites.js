// ═══════════════════════════════════════════════
//  처음 설치했을 때 켜져 있는 사이트 목록
//  ★ 여기 바꾸면 manifest.json 의 "host_permissions" 도 똑같이 변경 필요
// ═══════════════════════════════════════════════
var YUT_DEFAULT_SITES = [
  // AI 채팅 플랫폼
  'caveduck.io',
  'teapotchat.com',
  'rofan.ai',
  'elyn.ai',
  'lumo.gg',
  'zeta-ai.io',
  'crack.wrtn.ai',
  // 소설류.. 나중에 더 추가
  'archiveofourown.org',
  'postype.com',
  'pixiv.net',
];

var YUT_APP_PATTERN = 'https://purewith.me/*';
var YUT_ALL_PATTERN = '*://*/*';

// 'https://caveduck.io/ko' · 'www.Caveduck.io' · 'caveduck.io' → 'caveduck.io'
function yutHostFromInput(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return null;
  if (!/^[a-z]+:\/\//.test(s)) s = 'https://' + s;
  try {
    const u = new URL(s);
    if (!/^https?:$/.test(u.protocol)) return null;
    let h = u.hostname.replace(/^www\./, '').replace(/\.$/, '');
    if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(h)) return null;
    return h;
  } catch (e) {
    return null;
  }
}

function yutPatterns(host) {
  return [`*://*.${host}/*`];
}

// 지금 페이지 주소 > 목록의 어느 사이트에 속하는지
function yutMatchHost(hostname, sites) {
  const h = String(hostname || '').toLowerCase().replace(/\.$/, '');
  return (sites || []).find((s) => h === s || h.endsWith('.' + s)) || null;
}
