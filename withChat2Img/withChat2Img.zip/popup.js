const $ = (id) => document.getElementById(id);
const SITE_DEFAULTS = { sites: YUT_DEFAULT_SITES, allSites: false };

let current = null; // { host, matched, pats }

function say(text, err) {
  $('msg').textContent = text || '';
  $('msg').classList.toggle('err', !!err);
}

async function render() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const { sites, allSites } = await chrome.storage.sync.get(SITE_DEFAULTS);
  let url;
  try { url = new URL(tab?.url || ''); } catch (e) { url = null; }

  const toggle = $('toggle'), note = $('note'), state = $('state');
  toggle.hidden = true;
  note.hidden = true;
  state.className = 'state';

  // 브라우저 설정 화면 같은 곳
  if (!url || !/^https?:$/.test(url.protocol)) {
    $('host').textContent = '이 페이지';
    state.textContent = '사용할 수 없는 페이지';
    note.hidden = false;
    note.textContent = '브라우저 설정 화면, 새 탭, 스토어 같은 곳에서는 확장프로그램이 동작하지 않습니다.';
    return;
  }

  const hostname = url.hostname.replace(/^www\./, '');
  $('host').textContent = hostname;

  if (hostname === 'purewith.me') {
    state.textContent = '발췌기 사이트';
    note.hidden = false;
    note.textContent = '발췌기에서는 드래그 버튼이 뜨지 않습니다. 다른 사이트에서 글을 드래그해 보세요.';
    return;
  }

  const matched = yutMatchHost(hostname, sites);
  const host = matched || hostname;
  current = { host, matched, pats: yutPatterns(host) };

  if (allSites) {
    state.textContent = '모든 사이트에서 켜짐';
    state.classList.add('on');
    note.hidden = false;
    note.innerHTML = '설정에서 <b>모든 사이트에서 켜기</b>가 켜져 있어 이 사이트에서도 버튼이 뜹니다.';
    return;
  }

  const on = !!matched;
  state.textContent = on ? '드래그 버튼 켜짐' : '드래그 버튼 꺼짐';
  state.classList.toggle('on', on);
  toggle.hidden = false;
  toggle.textContent = on ? '이 사이트에서 끄기' : '✦ 이 사이트에서 켜기';
  toggle.classList.toggle('off', on);
  toggle.dataset.on = on ? '1' : '';
  if (!on) {
    note.hidden = false;
    note.innerHTML = '켜면 <b>' + host + '</b> 에서 글을 드래그할 때 발췌 버튼이 뜹니다.';
  }
}

$('toggle').addEventListener('click', () => {
  if (!current) return;
  const { host, matched, pats } = current;

  if ($('toggle').dataset.on) {
    // 끄기
    chrome.storage.sync.get(SITE_DEFAULTS).then(async ({ sites }) => {
      await chrome.storage.sync.set({ sites: sites.filter((s) => s !== matched) });
      if (!YUT_DEFAULT_SITES.includes(matched)) chrome.permissions.remove({ origins: pats }).catch(() => {});
      say('이 사이트에서 버튼을 껐습니다.');
      // 새 버전 알림
chrome.storage.local.get({ update: null }).then(({ update }) => {
  if (!update?.hasUpdate) return;
  $('newver').hidden = false;
  $('newverTitle').textContent = `새 버전 v${update.latest} 이 있습니다`;
  $('newverNote').textContent = update.note || `지금 쓰는 버전 v${chrome.runtime.getManifest().version}`;
});
$('newver').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'yut-open-download' });
  window.close();
});

render();
    });
    return;
  }

  // 켜기 — 권한 요청은 클릭 직후 바로 해야 해서 다른 작업보다 먼저 불러요
  chrome.permissions.request({ origins: pats }).then(async (granted) => {
    if (!granted) { say('권한을 허용해야 이 사이트에서 버튼을 띄울 수 있습니다.', true); return; }
    const { sites } = await chrome.storage.sync.get(SITE_DEFAULTS);
    if (!sites.includes(host)) await chrome.storage.sync.set({ sites: [...sites, host] });
    await chrome.runtime.sendMessage({ type: 'yut-site-on', host }).catch(() => {});
    say('켜졌습니다! 바로 드래그해 보세요.');
    // 새 버전 알림
chrome.storage.local.get({ update: null }).then(({ update }) => {
  if (!update?.hasUpdate) return;
  $('newver').hidden = false;
  $('newverTitle').textContent = `새 버전 v${update.latest} 이 있습니다`;
  $('newverNote').textContent = update.note || `지금 쓰는 버전 v${chrome.runtime.getManifest().version}`;
});
$('newver').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'yut-open-download' });
  window.close();
});

render();
  }).catch(() => say('권한을 요청하지 못했습니다.', true));
});

$('openApp').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'yut-open-app' });
  window.close();
});
$('openOptions').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

// 새 버전 알림
chrome.storage.local.get({ update: null }).then(({ update }) => {
  if (!update?.hasUpdate) return;
  $('newver').hidden = false;
  $('newverTitle').textContent = `새 버전 v${update.latest} 이 있습니다`;
  $('newverNote').textContent = update.note || `지금 쓰는 버전 v${chrome.runtime.getManifest().version}`;
});
$('newver').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'yut-open-download' });
  window.close();
});

render();