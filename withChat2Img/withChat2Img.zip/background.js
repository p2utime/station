importScripts('inject.js', 'sites.js');

const APP_URL = 'https://purewith.me/Chat2Img/';

// ---------- 새 버전 알림 ----------
// 다운로드 페이지 옆에 올려 둔 version.json 을 가끔 확인해요.
const VERSION_URL = 'https://purewith.me/withChat2Img/version.json';
const DOWNLOAD_URL = 'https://purewith.me/withChat2Img/';
const CHECK_EVERY_MIN = 360; // 6시간마다

function newerThan(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
}

async function checkUpdate() {
  const current = chrome.runtime.getManifest().version;
  let info = null;
  try {
    const r = await fetch(VERSION_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (r.ok) info = await r.json();
  } catch (e) {}
  const latest = info && info.version ? String(info.version) : null;
  const hasUpdate = !!latest && newerThan(latest, current);
  const update = { latest, hasUpdate, date: info?.date || '', note: info?.note || '', checkedAt: Date.now(), ok: !!info };
  await chrome.storage.local.set({ update });
  await chrome.action.setBadgeText({ text: hasUpdate ? 'NEW' : '' });
  if (hasUpdate) await chrome.action.setBadgeBackgroundColor({ color: '#2FA4DE' });
  if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: '#FFFFFF' }).catch(() => {});
  return update;
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'yut-update') checkUpdate(); });
function scheduleUpdateCheck() {
  chrome.alarms.create('yut-update', { delayInMinutes: 1, periodInMinutes: CHECK_EVERY_MIN });
  checkUpdate();
}
chrome.runtime.onStartup.addListener(scheduleUpdateCheck);

const DEFAULTS = {
  showBubble: true,
  focusOnSend: false,
  cleanText: true,
  speakerChips: 2,
};

const getSettings = () => chrome.storage.sync.get(DEFAULTS);

// ---------- 메뉴 ----------
chrome.runtime.onInstalled.addListener((details) => {
  syncContentScripts();
  scheduleUpdateCheck();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'yut-new', title: '새 발췌', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'yut-add', title: '이어 붙이기', contexts: ['selection'] });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const res = await sendExcerpt({ text: info.selectionText || '', replace: info.menuItemId === 'yut-new' });
  notify(tab?.id, res);
});

// ---------- 단축키 ----------
chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd !== 'send-selection') return;
  tab = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab) return;
  let text = '';
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: () => String(getSelection() || ''),
    });
    text = results.map((r) => r.result).find((t) => t && t.trim()) || '';
  } catch (e) {}
  const res = await sendExcerpt({ text, replace: true });
  notify(tab.id, res);
});

// ---------- 버튼이 뜨는 사이트 관리 ----------
// 켜 둔 사이트(+ 권한을 받은 사이트)에만 content.js 를 넣어요.
const SITE_DEFAULTS = { sites: YUT_DEFAULT_SITES, allSites: false };
let syncing = Promise.resolve();

function syncContentScripts() {
  syncing = syncing.then(doSync, doSync);
  return syncing;
}

async function doSync() {
  const { sites, allSites } = await chrome.storage.sync.get(SITE_DEFAULTS);
  let matches = [];
  if (allSites && (await chrome.permissions.contains({ origins: [YUT_ALL_PATTERN] }))) {
    matches = [YUT_ALL_PATTERN];
  } else {
    for (const host of sites) {
      const pats = yutPatterns(host);
      try {
        if (await chrome.permissions.contains({ origins: pats })) matches.push(...pats);
      } catch (e) {}
    }
  }
  matches.push(YUT_APP_PATTERN); // 발췌기 페이지 (모드 알림용)
  matches = [...new Set(matches)];
  try { await chrome.scripting.unregisterContentScripts({ ids: ['yut-content'] }); } catch (e) {}
  await chrome.scripting.registerContentScripts([{
    id: 'yut-content',
    js: ['sites.js', 'content.js'],
    matches,
    runAt: 'document_idle',
    allFrames: true,
    persistAcrossSessions: true,
  }]);
}

chrome.runtime.onStartup.addListener(syncContentScripts);
chrome.permissions.onAdded.addListener(syncContentScripts);
chrome.permissions.onRemoved.addListener(syncContentScripts);
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'sync' && (ch.sites || ch.allSites)) syncContentScripts();
});

// 사이트를 켰을 때, 이미 열려 있는 그 사이트 탭에도 바로 넣어 줌 (새로고침 없이)
async function injectIntoOpenTabs(host) {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    let h = '';
    try { h = new URL(t.url || '').hostname; } catch (e) { continue; }
    if (host !== '*' && !yutMatchHost(h, [host])) continue;
    chrome.scripting.executeScript({
      target: { tabId: t.id, allFrames: true },
      files: ['sites.js', 'content.js'],
    }).catch(() => {});
  }
}

// ---------- 페이지에서 온 요청 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'yut-excerpt') {
    sendExcerpt(msg).then(sendResponse);
    return true;
  }
  if (msg?.type === 'yut-mode') {
    chrome.storage.local.set({ lastMode: msg.mode });
  }
  if (msg?.type === 'yut-open-options') chrome.runtime.openOptionsPage();
  if (msg?.type === 'yut-open-app') openApp();
  if (msg?.type === 'yut-check-update') {
    checkUpdate().then(sendResponse);
    return true;
  }
  if (msg?.type === 'yut-open-download') chrome.tabs.create({ url: DOWNLOAD_URL });
  if (msg?.type === 'yut-site-on') {
    syncContentScripts().then(() => injectIntoOpenTabs(msg.host)).then(() => sendResponse(true));
    return true;
  }
});

// ---------- 핵심 ----------
function cleanUp(t) {
  return t
    .replace(/\r\n?/g, '\n')
    .replace(/[ 　]/g, ' ')
    .replace(/[​‌‍﻿]/g, '')
    .split('\n')
    .map((l) => l.replace(/[ \t]+$/, ''))
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function normUrl(u) {
  try {
    const x = new URL(u);
    let p = x.pathname.replace(/index\.html?$/i, '').replace(/\/+$/, '');
    return x.origin === 'null' ? x.protocol + p : x.origin + p;
  } catch (e) {
    return '';
  }
}

async function findAppTab() {
  const tabs = await chrome.tabs.query({});
  const base = normUrl(APP_URL);
  return tabs.find((t) => t.url && normUrl(t.url) === base) || null;
}

function waitComplete(tabId, timeout = 20000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpd);
      resolve();
    };
    const onUpd = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') finish(); }).catch(finish);
    setTimeout(finish, timeout);
  });
}

async function openApp() {
  const tab = await findAppTab();
  if (tab) return focusTab(tab);
  chrome.tabs.create({ url: APP_URL });
}

async function focusTab(tab) {
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

async function sendExcerpt({ text = '', replace = false, speaker = null }) {
  const s = await getSettings();
  if (s.cleanText) text = cleanUp(text);
  else text = text.replace(/\r\n?/g, '\n');
  if (!text.trim()) return { ok: false, error: '보낼 텍스트가 없습니다.' };

  let tab = await findAppTab();
  let fresh = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: APP_URL, active: true });
    fresh = true;
  } else if (s.focusOnSend) {
    await focusTab(tab);
  }
  await waitComplete(tab.id);

  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: yutInjectExcerpt,
      args: [{ text, replace: !!replace, speaker, fresh }],
    });
    const res = r?.result || { ok: false, error: '발췌기에 넣지 못했습니다.' };
    if (res.mode) chrome.storage.local.set({ lastMode: res.mode });
    if (res.ok) {
      res.message = res.waiting
        ? '발췌기 탭에서 복원 여부를 고르면 들어갑니다'
        : replace ? '발췌기에 넣었습니다 ✓' : '발췌기 글 아래에 이어 붙였습니다 ✓';
    }
    return res;
  } catch (e) {
    return { ok: false, error: '발췌기 탭에 접근하지 못했습니다. 발췌기 탭을 새로고침한 뒤 다시 시도해 주세요.' };
  }
}

function notify(tabId, res) {
  if (!tabId) return;
  const text = res.ok ? res.message : res.error;
  chrome.tabs.sendMessage(tabId, { type: 'yut-toast', ok: res.ok, text }).catch(() => {
    // 버튼이 꺼진 사이트(우클릭·단축키로 보낸 경우)엔 간단한 알림만 띄움
    chrome.scripting.executeScript({
      target: { tabId },
      args: [text, res.ok],
      func: (msg, ok) => {
        const el = document.createElement('div');
        el.textContent = msg;
        el.style.cssText = 'all:initial;position:fixed;right:18px;bottom:18px;z-index:2147483647;padding:10px 14px;border-radius:12px;' +
          'font:700 13px/1.4 Pretendard,"Malgun Gothic",system-ui,sans-serif;color:#fff;box-shadow:0 6px 20px rgba(0,0,0,.2);background:' + (ok ? '#0E0F12' : '#e5484d');
        document.documentElement.appendChild(el);
        setTimeout(() => el.remove(), ok ? 1800 : 4000);
      },
    }).catch(() => {});
  });
}